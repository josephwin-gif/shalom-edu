// ── Language translations ────────────────────────────────────
export const translations = {
  en: {
    // Navbar
    nav_home:     'Home',
    nav_articles: 'Articles',
    nav_gallery:  'Gallery',
    nav_teachers: 'Teachers',
    nav_contact:  'Contact',

    // Hero
    hero_welcome:  'Welcome to',
    hero_tagline:  'Learning for Life, Growing in Community',
    hero_learn:    'Learn More',
    hero_contact:  'Contact Us',
    hero_scroll:   'Scroll',

    // Stats
    stat_founded:  'Year Founded',
    stat_students: 'Students',
    stat_teachers: 'Teachers',

    // About
    about_eyebrow:  'About Us',
    about_heading:  'Rooted in Community, Growing in Excellence',
    about_desc:     'Shalom Education Centre is a private school dedicated to nurturing young minds in a caring rural community. We believe every child deserves quality education, strong values, and a safe place to grow.',
    vision_label:   '🎯 Vision',
    vision_text:    '"To raise up future leaders who live with God-fearing wisdom, good character, responsibility, and who can contribute to their community and the world."',
    mission_label:  '📖 Mission',
    mission_intro:  'Shalom Education Centre stands together with families as a safe and warm place for young students attending government schools —',
    mission_1:      'To teach not only academic subjects but also Christian faith, discipline, ethics, and good character.',
    mission_2:      'To train students in good social skills and relationships, and to develop a spirit of responsibility.',
    mission_3:      'To encourage students\' individual talents, creative thinking, and future dreams.',
    mission_4:      'To nurture young people with a strong Christian faith who can be a light in their community.',
    mission_5:      'To prepare young people who will become good and contributing leaders in the future.',
    about_link:     'Meet our teachers →',

    // Latest News
    news_eyebrow:  'Updates',
    news_heading:  'Latest News',
    news_btn:      'View All Articles →',
    news_empty:    'No articles yet.',

    // Gallery
    gallery_eyebrow: 'Our Campus',
    gallery_heading: 'School Life',
    gallery_btn:     'View Full Gallery →',
    gallery_empty:   'No photos yet.',

    // Teachers
    teachers_eyebrow:  'Our People',
    teachers_heading:  'Meet Our Teachers',
    teachers_btn:      'Meet All Teachers →',
    teachers_empty:    'No teachers added yet.',

    // Pages — Articles
    articles_title: 'News & Articles',
    articles_desc:  'Stories, announcements and updates from Shalom Education Centre',
    filter_all:     'All',
    back_articles:  '← Back to Articles',

    // Pages — Gallery
    media_title:    'Gallery',
    media_desc:     'Moments from Shalom Education Centre',
    click_enlarge:  'photos · Click to enlarge',

    // Pages — Teachers
    teachers_title: 'Our Teachers',
    teachers_desc:  'The dedicated educators of Shalom Education Centre',

    // Pages — Contact
    contact_title:       'Get in Touch',
    contact_desc:        "We'd love to hear from you",
    contact_info:        'School Information',
    contact_form_title:  'Send Us a Message',
    label_name:          'Your Name *',
    label_email:         'Email Address *',
    label_message:       'Message *',
    ph_name:             'Full name',
    ph_email:            'your@email.com',
    ph_message:          'Write your message here...',
    btn_send:            'Send Message',
    btn_sending:         'Sending…',
    msg_success_title:   'Message sent!',
    msg_success_desc:    "Thank you for reaching out. We'll get back to you soon.",
    btn_another:         'Send another',
    err_fill:            'Please fill in all fields.',
    err_failed:          'Failed to send. Please try again.',
    label_address:       'Address',
    label_phone:         'Phone',
    label_email_lbl:     'Email',
    label_hours:         'Office Hours',
    label_line:          'LINE ID',
    find_us:             '📍 Find Us',

    // Footer
    footer_links:   'Quick Links',
    footer_contact: 'Contact',
    footer_copy:    '© {year} Shalom Education Centre. All rights reserved.',
  },

  my: {
    // Navbar
    nav_home:     'ပင်မစာမျက်နှာ',
    nav_articles:  'ဆောင်းပါးများ',
    nav_gallery:   'ဓာတ်ပုံများ',
    nav_teachers:  'ဆရာများ',
    nav_contact:   'ဆက်သွယ်ရန်',

    // Hero
    hero_welcome:  'မှကြိုဆိုပါသည်',
    hero_tagline:  'ဘဝအတွက် သင်ယူခြင်း၊ လူ့အဖွဲ့အစည်းအတွက် ကြီးထွားခြင်း',
    hero_learn:    'ပိုမိုသိရှိရန်',
    hero_contact:  'ဆက်သွယ်ရန်',
    hero_scroll:   'အောက်ကြည့်ရန်',

    // Stats
    stat_founded:  'တည်ထောင်သည့်နှစ်',
    stat_students: 'ကျောင်းသား/သူများ',
    stat_teachers: 'ဆရာ/မများ',

    // About
    about_eyebrow:  'ကျွန်ုပ်တို့အကြောင်း',
    about_heading:  'လူ့အဖွဲ့အစည်းနှင့် ရင်းနှီးကာ ထူးချွန်မှုဖြင့် ကြီးထွားခြင်း',
    about_desc:     'Shalom Education Centre သည် ကျေးလက်ဒေသ လူ့အဖွဲ့အစည်းတွင် လူငယ်များ၏ စိတ်ပညာကို ပြုစုပျိုးထောင်ရန် 헌신်သော ပုဂ္ဂလိကကျောင်းတစ်ခုဖြစ်သည်။ ကလေးတိုင်းသည် အရည်အသွေးပြည့်ဝသောပညာရေး၊ ခိုင်မာသောတန်ဖိုးများနှင့် ဘေးကင်းလုံခြုံသောနေရာကို ရရှိသင့်သည်ဟု ကျွန်ုပ်တို့ယုံကြည်သည်။',
    vision_label:   '🎯 ရည်မှန်းချက်',
    vision_text:    '"ဘုရားသခင်ကို ကြောက်ရွံ့သော ဉာဏ်ပညာဖြင့် အသက်ရှင်တတ်ပြီး၊ စာရိတ္တကောင်းမွန်သော၊ တာဝန်ယူတတ်သော၊ လူမှုအသိုင်းအဝိုင်းနှင့် ကမ္ဘာအတွက် အကျိုးပြုနိုင်သော အနာဂတ်ခေါင်းဆောင်လူငယ်များကို မွေးထုတ်ပေးရန်။"',
    mission_label:  '📖 ရည်ရွယ်ချက်',
    mission_intro:  'Shalom Education Centre သည် မိသားစုများစုပေါင်း၍ အစိုးရကျောင်းတက်ရောက်နေသော ကျောင်းသားလူငယ်များအတွက် လုံခြုံနွေးထွေးသော နေရာတစ်ခုအဖြစ် ရပ်တည်ပြီး —',
    mission_1:      'ပညာရေးဆိုင်ရာ သင်ခန်းစာများသာမက ခရစ်ယာန်တစ်ယောက်အနေဖြင့် အသက်ရှင်ရမည့် ယုံကြည်ခြင်း၊ စည်းကမ်း၊ ကျင့်ဝတ်နှင့် စာရိတ္တကောင်းမွန်မှုများကို သင်ကြားပေးရန်။',
    mission_2:      'ကျောင်းသားများ၏ လူမှုပတ်ဝန်းကျင်နှင့် ပေါင်းသင်းဆက်ဆံရေးကောင်းမွန်စေရန်၊ တာဝန်ယူတတ်သော စိတ်ဓာတ်များ ရှိလာစေရန် လေ့ကျင့်ပေးရန်။',
    mission_3:      'ကျောင်းသားလူငယ်များ၏ ကိုယ်ပိုင်အရည်အချင်း၊ လွတ်လပ်စွာ စဉ်းစားဖန်တီးနိုင်စွမ်းနှင့် အနာဂတ်အိပ်မက်များကို အားပေးထောက်ပံ့ပေးရန်။',
    mission_4:      'ခိုင်မာသော ခရစ်ယာန်ယုံကြည်ခြင်းရှိပြီး လူ့အသိုင်းအဝိုင်းအတွက် အလင်းဖြစ်နိုင်သော လူငယ်များကို ပြုစုပျိုးထောင်ရန်။',
    mission_5:      'အနာဂတ်တွင် အကျိုးပြုသော ခေါင်းဆောင်ကောင်းများ ဖြစ်လာနိုင်မည့် လူငယ်များကို ပြင်ဆင်လေ့ကျင့်ပေးရန် ရည်ရွယ်ပါသည်။',
    about_link:     'ဆရာများကို တွေ့ဆုံပါ →',

    // Latest News
    news_eyebrow:  'နောက်ဆုံးသတင်းများ',
    news_heading:  'နောက်ဆုံးသတင်း',
    news_btn:      'ဆောင်းပါးအားလုံးကြည့်ရန် →',
    news_empty:    'ဆောင်းပါးများ မရှိသေးပါ။',

    // Gallery
    gallery_eyebrow: 'ကျွန်ုပ်တို့ကျောင်း',
    gallery_heading: 'ကျောင်းဘဝ',
    gallery_btn:     'ဓာတ်ပုံအားလုံးကြည့်ရန် →',
    gallery_empty:   'ဓာတ်ပုံများ မရှိသေးပါ။',

    // Teachers
    teachers_eyebrow: 'ကျွန်ုပ်တို့သူများ',
    teachers_heading: 'ဆရာမများနှင့် တွေ့ဆုံပါ',
    teachers_btn:     'ဆရာအားလုံးတွေ့ရန် →',
    teachers_empty:   'ဆရာများ မရှိသေးပါ။',

    // Pages — Articles
    articles_title: 'သတင်းနှင့် ဆောင်းပါးများ',
    articles_desc:  'Shalom Education Centre မှ သတင်းများ၊ ကြေညာချက်များနှင့် အပ်ဒိတ်များ',
    filter_all:     'အားလုံး',
    back_articles:  '← ဆောင်းပါးများသို့ ပြန်သွားရန်',

    // Pages — Gallery
    media_title:   'ဓာတ်ပုံများ',
    media_desc:    'Shalom Education Centre မှ အမှတ်တရများ',
    click_enlarge: 'ဓာတ်ပုံများ · ကြီးကြည့်ရန် နှိပ်ပါ',

    // Pages — Teachers
    teachers_title: 'ကျွန်ုပ်တို့ ဆရာများ',
    teachers_desc:  'Shalom Education Centre ၏ 헌身်သောဆရာများ',

    // Pages — Contact
    contact_title:       'ဆက်သွယ်ရန်',
    contact_desc:        'ကျွန်ုပ်တို့နှင့် ဆက်သွယ်ပါ',
    contact_info:        'ကျောင်းအချက်အလက်',
    contact_form_title:  'မက်ဆေ့ပို့ရန်',
    label_name:          'သင်၏အမည် *',
    label_email:         'အီးမေးလ်လိပ်စာ *',
    label_message:       'မက်ဆေ့ *',
    ph_name:             'အမည်အပြည့်အစုံ',
    ph_email:            'your@email.com',
    ph_message:          'သင်၏မက်ဆေ့ကို ဤနေရာတွင် ရေးပါ...',
    btn_send:            'မက်ဆေ့ပို့ရန်',
    btn_sending:         'ပို့နေသည်…',
    msg_success_title:   'မက်ဆေ့ပေးပို့ပြီးပါပြီ!',
    msg_success_desc:    'ဆက်သွယ်မှုအတွက် ကျေးဇူးတင်ပါသည်။ မကြာမီ ပြန်ကြားပါမည်။',
    btn_another:         'နောက်ထပ်ပို့ရန်',
    err_fill:            'ကျေးဇူးပြု၍ အကွက်များအားလုံး ဖြည့်ပါ။',
    err_failed:          'ပို့မရပါ။ နောက်တစ်ကြိမ် ကြိုးစားပါ။',
    label_address:       'လိပ်စာ',
    label_phone:         'ဖုန်းနံပါတ်',
    label_email_lbl:     'အီးမေးလ်',
    label_hours:         'ရုံးဖွင့်ချိန်',
    label_line:          'LINE ID',
    find_us:             '📍 ကျွန်ုပ်တို့ကို ရှာပါ',

    // Footer
    footer_links:   'အမြန်လင့်များ',
    footer_contact: 'ဆက်သွယ်ရန်',
    footer_copy:    '© {year} Shalom Education Centre။ မူပိုင်ခွင့်အားလုံးရှိသည်။',
  }
};

// ── Language manager ─────────────────────────────────────────
export function getLang() {
  return localStorage.getItem('shalom_lang') || 'en';
}
export function setLang(lang) {
  localStorage.setItem('shalom_lang', lang);
}
export function t(key) {
  const lang = getLang();
  return (translations[lang] && translations[lang][key]) || translations['en'][key] || key;
}

// ── Render language switcher button into navbar ──────────────
export function renderLangSwitcher() {
  const lang = getLang();
  const switcher = document.createElement('div');
  switcher.id = 'lang-switcher';
  switcher.style.cssText = 'display:flex;align-items:center;gap:4px;margin-left:0.5rem;';
  switcher.innerHTML = `
    <button id="btn-en" onclick="switchLang('en')" style="
      padding:0.28rem 0.7rem;border-radius:5px;border:1px solid rgba(201,168,76,0.4);
      background:${lang==='en'?'#C9A84C':'transparent'};
      color:${lang==='en'?'#1a3009':'rgba(245,240,232,0.7)'};
      font-size:0.78rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all 0.15s;">
      EN
    </button>
    <button id="btn-my" onclick="switchLang('my')" style="
      padding:0.28rem 0.7rem;border-radius:5px;border:1px solid rgba(201,168,76,0.4);
      background:${lang==='my'?'#C9A84C':'transparent'};
      color:${lang==='my'?'#1a3009':'rgba(245,240,232,0.7)'};
      font-size:0.78rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all 0.15s;">
      မြန်မာ
    </button>`;
  return switcher;
}

// Global switch function called by buttons
window.switchLang = function(lang) {
  setLang(lang);
  location.reload();
};

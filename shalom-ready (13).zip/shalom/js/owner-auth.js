// ── Owner Auth Module ─────────────────────────────────────
// Simple, reliable owner login popup for Calendar & Founder pages
import { supabase } from './supabase.js';

export async function isOwner() {
  if (sessionStorage.getItem('sims_role') === 'admin') {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) return true;
  }
  return false;
}

// Inject login popup CSS once
function injectCSS() {
  if (document.getElementById('owner-auth-css')) return;
  const s = document.createElement('style');
  s.id = 'owner-auth-css';
  s.textContent = `
    #owner-popup-overlay {
      position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:9999;
      display:flex;align-items:center;justify-content:center;padding:1rem;
    }
    #owner-popup-box {
      background:#fff;border-radius:16px;padding:2rem;width:100%;max-width:360px;
      box-shadow:0 16px 50px rgba(0,0,0,0.25);font-family:'Crimson Text',Georgia,serif;
    }
    #owner-popup-box h3 {
      font-family:'Playfair Display',Georgia,serif;color:#2D5016;
      font-size:1.2rem;margin:0 0 1.25rem;
    }
    .op-input {
      width:100%;padding:0.65rem 0.9rem;font-size:1rem;
      border:1px solid #d6c9b0;border-radius:8px;
      font-family:inherit;box-sizing:border-box;outline:none;
      transition:border-color 0.2s;margin-bottom:0.85rem;
    }
    .op-input:focus { border-color:#2D5016; }
    .op-btn-login {
      width:100%;background:#2D5016;color:#F5F0E8;border:none;
      border-radius:8px;padding:0.75rem;font-family:inherit;
      font-size:1rem;font-weight:700;cursor:pointer;transition:opacity 0.2s;
    }
    .op-btn-login:hover { opacity:0.88; }
    .op-btn-login:disabled { opacity:0.5;cursor:not-allowed; }
    .op-btn-cancel {
      width:100%;background:transparent;color:#8B5E3C;border:none;
      padding:0.5rem;font-family:inherit;font-size:0.9rem;cursor:pointer;
      margin-top:0.35rem;
    }
    .op-error {
      background:#fee2e2;border:1px solid #fca5a5;color:#991b1b;
      padding:0.6rem 0.9rem;border-radius:7px;font-size:0.88rem;
      margin-bottom:0.85rem;display:none;
    }
    #owner-bar-strip {
      position:fixed;bottom:0;left:0;right:0;z-index:9998;
      background:rgba(26,48,9,0.97);border-top:2px solid #C9A84C;
      padding:0.65rem 1.5rem;display:flex;align-items:center;
      justify-content:space-between;flex-wrap:wrap;gap:0.5rem;
      font-family:'Crimson Text',Georgia,serif;font-size:0.9rem;
      transform:translateY(100%);
      transition:transform 0.35s cubic-bezier(0.22,1,0.36,1);
    }
    #owner-bar-strip.visible { transform:translateY(0); }
    #owner-bar-strip span { color:rgba(245,240,232,0.75); }
    #owner-bar-strip strong { color:#C9A84C; }
    #owner-logout-btn {
      background:transparent;border:1px solid rgba(201,168,76,0.4);
      color:rgba(201,168,76,0.8);border-radius:7px;
      padding:0.3rem 0.9rem;font-family:inherit;font-size:0.85rem;
      cursor:pointer;transition:all 0.15s;
    }
    #owner-logout-btn:hover { border-color:#C9A84C;color:#C9A84C; }
    /* Add extra padding to page so bar doesn't cover content */
    body.owner-logged-in { padding-bottom:52px; }
  `;
  document.head.appendChild(s);
}

// Build the login popup DOM
function buildPopup() {
  if (document.getElementById('owner-popup-overlay')) return;
  const overlay = document.createElement('div');
  overlay.id = 'owner-popup-overlay';
  overlay.style.display = 'none';
  overlay.innerHTML = `
    <div id="owner-popup-box">
      <h3>🔐 Owner Login</h3>
      <div class="op-error" id="op-error"></div>
      <input class="op-input" id="op-email" type="email" placeholder="Admin email address">
      <input class="op-input" id="op-pass"  type="password" placeholder="Password">
      <button class="op-btn-login" id="op-login-btn">Login as Owner</button>
      <button class="op-btn-cancel" id="op-cancel-btn">Cancel</button>
    </div>`;
  document.body.appendChild(overlay);

  // Cancel
  document.getElementById('op-cancel-btn').addEventListener('click', closePopup);
  overlay.addEventListener('click', e => { if (e.target===overlay) closePopup(); });

  // Login
  document.getElementById('op-login-btn').addEventListener('click', doLogin);
  document.getElementById('op-pass').addEventListener('keydown', e => {
    if (e.key === 'Enter') doLogin();
  });
}

function openPopup() {
  const overlay = document.getElementById('owner-popup-overlay');
  if (overlay) {
    overlay.style.display = 'flex';
    setTimeout(() => document.getElementById('op-email')?.focus(), 50);
  }
}

function closePopup() {
  const overlay = document.getElementById('owner-popup-overlay');
  if (overlay) overlay.style.display = 'none';
  const err = document.getElementById('op-error');
  if (err) err.style.display = 'none';
}

async function doLogin() {
  const email = document.getElementById('op-email')?.value.trim();
  const pass  = document.getElementById('op-pass')?.value;
  const err   = document.getElementById('op-error');
  const btn   = document.getElementById('op-login-btn');

  if (!email || !pass) {
    err.textContent = 'Please enter both email and password.';
    err.style.display = 'block'; return;
  }

  btn.textContent = 'Logging in...'; btn.disabled = true;

  const { error } = await supabase.auth.signInWithPassword({ email, password: pass });

  if (error) {
    err.textContent = 'Wrong email or password. Please try again.';
    err.style.display = 'block';
    btn.textContent = 'Login as Owner'; btn.disabled = false;
  } else {
    sessionStorage.setItem('sims_role', 'admin');
    closePopup();
    // Reload page to show edit controls
    window.location.reload();
  }
}

// Build the owner bar (shown at bottom when logged in)
function buildOwnerBar(onLogout) {
  if (document.getElementById('owner-bar-strip')) return;
  const bar = document.createElement('div');
  bar.id = 'owner-bar-strip';
  bar.innerHTML = `
    <span>🔐 <strong>Owner mode</strong> — you can edit this page</span>
    <button id="owner-logout-btn">Logout</button>`;
  document.body.appendChild(bar);
  document.body.classList.add('owner-logged-in');
  requestAnimationFrame(() => bar.classList.add('visible'));

  document.getElementById('owner-logout-btn').addEventListener('click', async () => {
    await supabase.auth.signOut();
    sessionStorage.clear();
    bar.classList.remove('visible');
    document.body.classList.remove('owner-logged-in');
    setTimeout(() => { bar.remove(); if (onLogout) onLogout(); }, 350);
  });
}

// ── Main export ───────────────────────────────────────────
// Call this on any page that needs owner-only edit controls.
// onLogin()  → called immediately if already owner, or after login
// onLogout() → called when owner logs out
export async function initOwnerBar(onLogin, onLogout) {
  injectCSS();
  buildPopup();

  const owner = await isOwner();

  if (owner) {
    // Already logged in — show bar and call onLogin
    buildOwnerBar(onLogout);
    if (onLogin) onLogin();
  } else {
    // Not logged in — wire ALL elements with data-owner-login to open popup
    // We use event delegation so dynamically added elements also work
    document.addEventListener('click', e => {
      const trigger = e.target.closest('[data-owner-login], #owner-login-link, .owner-login-trigger');
      if (trigger) { e.preventDefault(); openPopup(); }
    });
  }

  return owner;
}

// Also export openPopup so pages can call it directly
export { openPopup as openOwnerLogin };

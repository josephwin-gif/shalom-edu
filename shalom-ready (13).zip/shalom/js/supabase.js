// ── Supabase config ──────────────────────────────────────────
// Replace these two values with your actual Supabase project details
// Found at: Supabase dashboard → Project Settings → API
const SUPABASE_URL  = 'https://moiiocahofilwodwtbnm.supabase.co';
const SUPABASE_KEY  = 'sb_publishable_q0faa6X_jAO5ZjLuIFzB-A_e-4N2r4W';

import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';
export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// ── Helpers ─────────────────────────────────────────────────

export function formatDate(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString('en-GB', {
    day: 'numeric', month: 'long', year: 'numeric'
  });
}

export function badgeClass(cat) {
  const map = {
    Events: 'badge-events', Academic: 'badge-academic',
    Sports: 'badge-sports', Announcement: 'badge-announcement'
  };
  return 'badge ' + (map[cat] || 'badge-general');
}

export function articleCard(a) {
  return `
    <a class="card" href="article.html?id=${a.id}">
      <div class="card-thumb">
        ${a.thumbnail_url
          ? `<img src="${a.thumbnail_url}" alt="${a.title}" loading="lazy">`
          : '📰'}
      </div>
      <div class="card-body">
        <div class="card-meta">
          <span class="${badgeClass(a.category)}">${a.category || 'General'}</span>
          <span class="card-date">${formatDate(a.published_at)}</span>
        </div>
        <h3 class="card-title">${a.title}</h3>
        <p class="card-excerpt">${a.excerpt || ''}</p>
      </div>
    </a>`;
}

export function teacherCardDark(t) {
  const initial = (t.name || 'T').charAt(0);
  const avatar  = t.photo_url
    ? `<img class="teacher-avatar" src="${t.photo_url}" alt="${t.name}">`
    : `<div class="teacher-avatar-placeholder">${initial}</div>`;
  return `
    <div class="teacher-card">
      ${avatar}
      <p class="teacher-name">${t.name}</p>
      <p class="teacher-pos">${t.position || ''}</p>
      <p class="teacher-subject">${t.subject || ''}</p>
    </div>`;
}

export function teacherCardLight(t) {
  const initial = (t.name || 'T').charAt(0);
  const avatar  = t.photo_url
    ? `<img class="teacher-avatar" src="${t.photo_url}" alt="${t.name}" style="border-color:var(--gold)">`
    : `<div class="teacher-avatar-placeholder" style="margin-bottom:1rem">${initial}</div>`;
  return `
    <div class="teacher-card-light">
      ${avatar}
      <p class="teacher-name" style="color:var(--green)">${t.name}</p>
      <p class="teacher-pos">${t.position || ''}</p>
      <p class="teacher-subject" style="color:var(--brown)">${t.subject || ''}</p>
      ${t.bio ? `<p class="teacher-bio">${t.bio}</p>` : ''}
    </div>`;
}

export function skeleton(h = '200px') {
  return `<div class="skeleton" style="height:${h}"></div>`;
}

export async function loadSchoolInfo() {
  const { data } = await supabase.from('school_info').select('*').limit(1).single();
  return data || {};
}

// ── Navbar loader ────────────────────────────────────────────
export async function initNavbar(activePage) {
  const info = await loadSchoolInfo();
  const logoHtml = info.logo_url
    ? `<img src="${info.logo_url}" alt="Logo" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--gold)">`
    : `<img src="images/logo.jpg" alt="Logo" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--gold)" onerror="this.outerHTML='<span style=font-size:1.4rem>🏫</span>'">`;

  // Import translations
  const { t, renderLangSwitcher, getLang } = await import('./lang.js');
  const lang = getLang();

  // Detect if we are inside the sims/ subfolder
  const inSims = window.location.pathname.includes('/sims/');
  const base   = inSims ? '../' : '';

  const pages = [
    [t('nav_home'),     `${base}index.html`,    'Home'],
    [t('nav_articles'), `${base}articles.html`, 'Articles'],
    [t('nav_gallery'),  `${base}media.html`,    'Gallery'],
    [t('nav_teachers'), `${base}teachers.html`, 'Teachers'],
    ['📅 Calendar',     `${base}calendar.html`, 'Calendar'],
    ['🕊️ Founder',     `${base}founder.html`,  'Founder'],
    [t('nav_contact'),  `${base}contact.html`,  'Contact'],
    ['📋 SIMS',         `${base}sims/index.html`, 'SIMS'],
  ];
  const links = pages.map(([label, href, key]) => {
    const active  = activePage === key ? ' class="active"' : '';
    const isCta   = key === 'Contact';
    const isSims  = key === 'SIMS';
    let cls = active || (isCta ? ' class="nav-cta"' : '');
    const extra = isSims ? ' style="color:#C9A84C;font-weight:700"' : '';
    return `<li><a href="${href}"${cls}${extra}>${label}</a></li>`;
  }).join('');

  document.getElementById('navbar-brand-logo').innerHTML = logoHtml;
  document.getElementById('navbar-brand-name').textContent = 'Shalom Education Centre';
  document.getElementById('nav-links').innerHTML = links;

  // Inject language switcher after nav-links
  const navbar = document.querySelector('.navbar');
  navbar.appendChild(renderLangSwitcher());

  // Hamburger toggle
  document.getElementById('hamburger').addEventListener('click', () => {
    document.getElementById('nav-links').classList.toggle('open');
  });
}

// ── Footer loader ────────────────────────────────────────────
export async function initFooter(info) {
  if (!info) info = await loadSchoolInfo();
  const { t } = await import('./lang.js');
  const logoHtml = info.logo_url ? `<img src="${info.logo_url}" alt="Logo">` : '';
  const socials = [
    info.facebook_url && `<a href="${info.facebook_url}" target="_blank" rel="noopener">FB</a>`,
    info.youtube_url  && `<a href="${info.youtube_url}"  target="_blank" rel="noopener">YT</a>`,
    info.line_id      && `<a href="https://line.me/ti/p/${info.line_id}" target="_blank" rel="noopener">LN</a>`,
  ].filter(Boolean).join('');

  document.getElementById('footer').innerHTML = `
    <div class="footer-inner">
      <div class="footer-grid">
        <div>
          <div class="footer-logo">${logoHtml}<span>Shalom Education Centre</span></div>
          <p class="footer-tagline">${info.tagline || t('hero_tagline')}</p>
          <div class="footer-social">${socials}</div>
        </div>
        <div class="footer-col">
          <h4>${t('footer_links')}</h4>
          <a href="index.html">${t('nav_home')}</a>
          <a href="articles.html">${t('nav_articles')}</a>
          <a href="media.html">${t('nav_gallery')}</a>
          <a href="teachers.html">${t('nav_teachers')}</a>
          <a href="contact.html">${t('nav_contact')}</a>
        </div>
        <div class="footer-col">
          <h4>${t('footer_contact')}</h4>
          ${info.address ? `<p>📍 ${info.address}</p>` : ''}
          ${info.phone   ? `<p>📞 ${info.phone}</p>`   : ''}
          ${info.email   ? `<p>✉️ ${info.email}</p>`   : ''}
        </div>
      </div>
      <div class="footer-bottom">
        ${t('footer_copy').replace('{year}', new Date().getFullYear())}
      </div>
    </div>`;
}

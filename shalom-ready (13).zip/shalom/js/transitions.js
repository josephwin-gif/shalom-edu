// ── Shalom Page Transition Engine ───────────────────────────
// Fade-out on leave → slide-up + fade-in on arrive
// Fast (280ms leave, 340ms enter), GPU-accelerated, zero jank

(function () {
  'use strict';

  // ── Inject transition styles once ──────────────────────────
  const style = document.createElement('style');
  style.textContent = `
    /* Page wrapper animation states */
    body {
      opacity: 1;
      transform: translateY(0px);
      transition: opacity 0.28s ease, transform 0.28s ease;
    }
    body.page-leaving {
      opacity: 0;
      transform: translateY(-12px);
      pointer-events: none;
    }
    body.page-entering {
      opacity: 0;
      transform: translateY(18px);
    }
    body.page-visible {
      opacity: 1;
      transform: translateY(0px);
      transition: opacity 0.34s cubic-bezier(0.22,1,0.36,1),
                  transform 0.34s cubic-bezier(0.22,1,0.36,1);
    }

    /* Progress bar at very top */
    #page-progress {
      position: fixed;
      top: 0; left: 0;
      height: 3px;
      width: 0%;
      background: linear-gradient(90deg, #C9A84C, #2D5016, #C9A84C);
      background-size: 200% 100%;
      z-index: 9999;
      border-radius: 0 2px 2px 0;
      transition: width 0.25s ease, opacity 0.3s ease;
      animation: shimmer-bar 1.4s linear infinite;
      opacity: 0;
      pointer-events: none;
    }
    #page-progress.active {
      opacity: 1;
    }
    @keyframes shimmer-bar {
      0%   { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }

    /* Nav link hover underline sweep */
    .nav-links a {
      position: relative;
    }
    .nav-links a::after {
      content: '';
      position: absolute;
      bottom: -2px; left: 50%; right: 50%;
      height: 2px;
      background: #C9A84C;
      border-radius: 2px;
      transition: left 0.22s ease, right 0.22s ease;
    }
    .nav-links a:hover::after,
    .nav-links a.active::after {
      left: 8px; right: 8px;
    }

    /* Card entrance animation */
    @keyframes card-in {
      from { opacity: 0; transform: translateY(22px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .card, .sims-card, .teacher-card-light,
    .stat-card, .contact-card, .guardian-card {
      animation: card-in 0.42s cubic-bezier(0.22,1,0.36,1) both;
    }

    /* Stagger cards */
    .cards-grid .card:nth-child(1),
    .teachers-grid .teacher-card-light:nth-child(1),
    .stat-cards .stat-card:nth-child(1) { animation-delay: 0.06s; }
    .cards-grid .card:nth-child(2),
    .teachers-grid .teacher-card-light:nth-child(2),
    .stat-cards .stat-card:nth-child(2) { animation-delay: 0.12s; }
    .cards-grid .card:nth-child(3),
    .teachers-grid .teacher-card-light:nth-child(3),
    .stat-cards .stat-card:nth-child(3) { animation-delay: 0.18s; }
    .cards-grid .card:nth-child(4),
    .teachers-grid .teacher-card-light:nth-child(4),
    .stat-cards .stat-card:nth-child(4) { animation-delay: 0.24s; }
    .cards-grid .card:nth-child(n+5)    { animation-delay: 0.28s; }

    /* Gallery items pop in */
    @keyframes gallery-in {
      from { opacity: 0; transform: scale(0.94); }
      to   { opacity: 1; transform: scale(1); }
    }
    .gallery-item {
      animation: gallery-in 0.38s cubic-bezier(0.22,1,0.36,1) both;
    }
    .gallery-grid .gallery-item:nth-child(1) { animation-delay: 0.04s; }
    .gallery-grid .gallery-item:nth-child(2) { animation-delay: 0.09s; }
    .gallery-grid .gallery-item:nth-child(3) { animation-delay: 0.14s; }
    .gallery-grid .gallery-item:nth-child(4) { animation-delay: 0.19s; }
    .gallery-grid .gallery-item:nth-child(5) { animation-delay: 0.23s; }
    .gallery-grid .gallery-item:nth-child(6) { animation-delay: 0.27s; }
    .gallery-grid .gallery-item:nth-child(n+7) { animation-delay: 0.30s; }

    /* Hero content slides up on load */
    @keyframes hero-in {
      from { opacity: 0; transform: translateY(28px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .hero-content { animation: hero-in 0.55s cubic-bezier(0.22,1,0.36,1) 0.1s both; }
    .stats-bar    { animation: hero-in 0.5s cubic-bezier(0.22,1,0.36,1) 0.2s both; }

    /* Section headers fade in */
    @keyframes section-in {
      from { opacity: 0; transform: translateY(14px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .section-header, .page-header, .sims-header {
      animation: section-in 0.45s cubic-bezier(0.22,1,0.36,1) 0.05s both;
    }

    /* Navbar slide down */
    @keyframes nav-in {
      from { opacity: 0; transform: translateY(-100%); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .navbar { animation: nav-in 0.38s cubic-bezier(0.22,1,0.36,1) both; }

    /* Table rows stagger in */
    @keyframes row-in {
      from { opacity: 0; transform: translateX(-10px); }
      to   { opacity: 1; transform: translateX(0); }
    }
    .sims-table tbody tr {
      animation: row-in 0.32s ease both;
    }
    .sims-table tbody tr:nth-child(1) { animation-delay: 0.04s; }
    .sims-table tbody tr:nth-child(2) { animation-delay: 0.08s; }
    .sims-table tbody tr:nth-child(3) { animation-delay: 0.12s; }
    .sims-table tbody tr:nth-child(4) { animation-delay: 0.16s; }
    .sims-table tbody tr:nth-child(5) { animation-delay: 0.20s; }
    .sims-table tbody tr:nth-child(n+6) { animation-delay: 0.24s; }

    /* Smooth button press */
    .sims-btn:active, .btn-primary:active,
    .btn-outline-green:active, .tbl-btn:active {
      transform: scale(0.96);
      transition: transform 0.1s ease;
    }

    /* About section image zoom-in */
    @keyframes img-in {
      from { opacity: 0; transform: scale(0.96); }
      to   { opacity: 1; transform: scale(1); }
    }
    .about-img { animation: img-in 0.55s cubic-bezier(0.22,1,0.36,1) 0.15s both; }

    /* Reduced motion — respect user preference */
    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        animation-duration: 0.01ms !important;
        transition-duration: 0.01ms !important;
      }
    }
  `;
  document.head.appendChild(style);

  // ── Progress bar element ────────────────────────────────────
  const bar = document.createElement('div');
  bar.id = 'page-progress';
  function insertBar() {
    if (document.body) {
      document.body.insertBefore(bar, document.body.firstChild);
    } else {
      document.addEventListener('DOMContentLoaded', function() {
        document.body.insertBefore(bar, document.body.firstChild);
      });
    }
  }
  insertBar();

  let barTimer = null;

  function startBar() {
    bar.style.width = '0%';
    bar.classList.add('active');
    let w = 0;
    clearInterval(barTimer);
    barTimer = setInterval(() => {
      w += (100 - w) * 0.12;
      bar.style.width = Math.min(w, 88) + '%';
    }, 40);
  }

  function finishBar() {
    clearInterval(barTimer);
    bar.style.width = '100%';
    setTimeout(() => {
      bar.classList.remove('active');
      bar.style.width = '0%';
    }, 320);
  }

  // ── Enter animation on page load ───────────────────────────
  document.body.classList.add('page-entering');
  window.addEventListener('load', () => {
    requestAnimationFrame(() => {
      document.body.classList.remove('page-entering');
      document.body.classList.add('page-visible');
    });
  });

  // ── Intercept all internal link clicks ─────────────────────
  function isInternalLink(el) {
    if (!el || el.tagName !== 'A') return false;
    const href = el.getAttribute('href');
    if (!href) return false;
    if (href.startsWith('http') || href.startsWith('//')) return false;
    if (href.startsWith('mailto:') || href.startsWith('tel:')) return false;
    if (href.startsWith('#')) return false;
    if (el.target === '_blank') return false;
    return true;
  }

  document.addEventListener('click', function (e) {
    // Walk up DOM to find <a>
    let el = e.target;
    while (el && el.tagName !== 'A') el = el.parentElement;
    if (!isInternalLink(el)) return;

    e.preventDefault();
    const href = el.getAttribute('href');

    startBar();
    document.body.classList.remove('page-visible');
    document.body.classList.add('page-leaving');

    setTimeout(() => {
      finishBar();
      window.location.href = href;
    }, 260);
  }, true);

  // ── Handle browser back/forward ────────────────────────────
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) {
      document.body.classList.remove('page-leaving');
      document.body.classList.add('page-entering');
      requestAnimationFrame(() => {
        document.body.classList.remove('page-entering');
        document.body.classList.add('page-visible');
      });
    }
  });

})();

// ── SIMS Auth Guard ─────────────────────────────────────────
// Import this in every SIMS admin page to protect it

import { supabase } from '../js/supabase.js';

export async function requireAdmin() {
  const role = sessionStorage.getItem('sims_role');
  if (role === 'admin') {
    // Verify Supabase session is still valid
    const { data: { session } } = await supabase.auth.getSession();
    if (session) return true;
  }
  // Not logged in — redirect to login
  sessionStorage.clear();
  window.location.href = 'login.html';
  return false;
}

export function getRole() {
  return sessionStorage.getItem('sims_role');
}

export function logout() {
  supabase.auth.signOut();
  sessionStorage.clear();
  window.location.href = 'login.html';
}

// ── Generate student code from name ──────────────────────────
// "Joseph Win" → "Jw", then pad with sequence → "Jw-001"
export function generateStudentCode(fullName, sequence) {
  const parts = (fullName || '').trim().split(/\s+/);
  let prefix = '';
  if (parts.length >= 2) {
    // First letter of first name + first letter of last name
    prefix = parts[0].charAt(0).toUpperCase() + parts[parts.length - 1].charAt(0).toLowerCase();
  } else if (parts.length === 1) {
    // Just first two letters
    prefix = parts[0].substring(0, 2);
    prefix = prefix.charAt(0).toUpperCase() + prefix.charAt(1).toLowerCase();
  } else {
    prefix = 'St';
  }
  const num = String(sequence).padStart(3, '0');
  return `${prefix}-${num}`;
}

-- ═══════════════════════════════════════════════════════════
--  SHALOM — Calendar & Founder Setup SQL
--  Run in: Supabase → SQL Editor → New Query → Run
-- ═══════════════════════════════════════════════════════════

-- ── 1. School Events (Calendar) ─────────────────────────────
CREATE TABLE IF NOT EXISTS school_events (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  title       text        NOT NULL,
  event_type  text        DEFAULT 'other',
  start_date  date        NOT NULL,
  end_date    date,
  description text,
  created_at  timestamptz DEFAULT now()
);

ALTER TABLE school_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read events"  ON school_events;
DROP POLICY IF EXISTS "Public write events" ON school_events;
CREATE POLICY "Public read events"
  ON school_events FOR SELECT USING (true);
CREATE POLICY "Public write events"
  ON school_events FOR ALL USING (true) WITH CHECK (true);

-- ── 2. Founder Info ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS founder_info (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name           text,
  role           text,
  quote          text,
  quote_en       text,
  quote_my       text,
  message        text,
  message_en     text,
  message_my     text,
  inspiration    text,
  inspiration_en text,
  inspiration_my text,
  vision         text,
  vision_en      text,
  vision_my      text,
  values         text,
  photo_url      text,
  updated_at     timestamptz DEFAULT now(),
  created_at     timestamptz DEFAULT now()
);

-- Add columns safely if table already exists
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS quote_en       text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS quote_my       text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS message_en     text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS message_my     text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS inspiration_en text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS inspiration_my text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS vision_en      text;
ALTER TABLE founder_info ADD COLUMN IF NOT EXISTS vision_my      text;

ALTER TABLE founder_info ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read founder"  ON founder_info;
DROP POLICY IF EXISTS "Public write founder" ON founder_info;
CREATE POLICY "Public read founder"
  ON founder_info FOR SELECT USING (true);
CREATE POLICY "Public write founder"
  ON founder_info FOR ALL USING (true) WITH CHECK (true);

-- ── 3. Sample calendar events ────────────────────────────────
INSERT INTO school_events (title, event_type, start_date, end_date, description)
SELECT * FROM (VALUES
  ('School Year Begins',        'academic',  '2025-06-02'::date, NULL,               'First day of the new academic year'),
  ('Mid-Term Examinations',     'exam',      '2025-07-14'::date, '2025-07-18'::date, 'Mid-term exams for all grades'),
  ('Sports Day',                'activity',  '2025-08-08'::date, NULL,               'Annual sports competition for all students'),
  ('Christian Education Week',  'academic',  '2025-08-18'::date, '2025-08-22'::date, 'Special week focused on Christian values'),
  ('End of Term Exams',         'exam',      '2025-09-15'::date, '2025-09-19'::date, 'End of first term examinations'),
  ('Karen New Year Holiday',    'holiday',   '2025-01-09'::date, NULL,               'Karen New Year holiday'),
  ('Christmas Celebration',     'activity',  '2025-12-23'::date, NULL,               'School Christmas celebration and carol singing'),
  ('Graduation Ceremony',       'activity',  '2025-03-20'::date, NULL,               'Annual graduation ceremony')
) AS v(title, event_type, start_date, end_date, description)
WHERE NOT EXISTS (SELECT 1 FROM school_events LIMIT 1);

-- ── 4. Sample founder record ─────────────────────────────────
INSERT INTO founder_info (
  name, role,
  quote_en, message_en, inspiration_en, vision_en,
  quote_my, message_my, inspiration_my, vision_my,
  values
)
SELECT
  'Founder Name',
  'Founder & Director',
  'Every child deserves a place where they are known, loved, and inspired to grow.',
  'Welcome to Shalom Education Centre. Click "Edit Content" on the Founder page to add a personal message.',
  'Click "Edit Content" to add the story of why Shalom Education Centre was founded.',
  'Click "Edit Content" to add the founder''s vision for the school.',
  'ကလေးတိုင်းသည် သိမှတ်ခြင်းခံရပြီး ချစ်ခင်ကာ ကြီးထွားရန် နေရာတစ်ခု လိုအပ်သည်။',
  'Shalom Education Centre မှ ကြိုဆိုပါသည်။ တည်ထောင်သူ၏ မက်ဆေ့ကို ထည့်သွင်းရန် "Edit Content" ကို နှိပ်ပါ။',
  'Shalom Education Centre ကို တည်ထောင်ရသောအကြောင်းရင်းကို ထည့်သွင်းပါ။',
  'ကျောင်းအတွက် အနာဂတ်ရည်မှန်းချက်ကို ထည့်သွင်းပါ။',
  '[{"icon":"✝️","title":"Faith","desc":"Rooted in Christian values"},{"icon":"📚","title":"Excellence","desc":"High academic standards"},{"icon":"❤️","title":"Love","desc":"Every child is known and loved"},{"icon":"🌱","title":"Growth","desc":"Holistic development"},{"icon":"🤝","title":"Community","desc":"Serving the local community"},{"icon":"🕊️","title":"Peace","desc":"Shalom — peace in all things"}]'
WHERE NOT EXISTS (SELECT 1 FROM founder_info LIMIT 1);

-- ── 5. Copy old data to new columns if upgrading ─────────────
UPDATE founder_info SET
  quote_en       = COALESCE(quote_en, quote),
  message_en     = COALESCE(message_en, message),
  inspiration_en = COALESCE(inspiration_en, inspiration),
  vision_en      = COALESCE(vision_en, vision)
WHERE quote_en IS NULL AND quote IS NOT NULL;

-- ═══════════════════════════════════════════════════════════
--  Done! Visit /calendar.html and /founder.html on your site.
-- ═══════════════════════════════════════════════════════════

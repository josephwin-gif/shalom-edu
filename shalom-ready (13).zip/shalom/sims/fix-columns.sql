-- ═══════════════════════════════════════════════════════════
--  QUICK FIX — Run in Supabase → SQL Editor → New Query
--  Fixes: Student ID showing blank, stats showing –
-- ═══════════════════════════════════════════════════════════

-- Step 1: Add missing columns to students table
ALTER TABLE students ADD COLUMN IF NOT EXISTS student_code text;
ALTER TABLE students ADD COLUMN IF NOT EXISTS age          integer;
ALTER TABLE students ADD COLUMN IF NOT EXISTS address      text;

-- Step 2: Make student_code unique (skip if already done)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'students_student_code_key'
  ) THEN
    ALTER TABLE students ADD CONSTRAINT students_student_code_key UNIQUE (student_code);
  END IF;
END $$;

-- Step 3: Auto-generate student_code for existing students that have none
-- This gives them codes like Se-001, Se-002, etc. based on their name
DO $$
DECLARE
  rec     RECORD;
  prefix  TEXT;
  parts   TEXT[];
  seq     INTEGER;
  code    TEXT;
BEGIN
  FOR rec IN
    SELECT id, full_name
    FROM students
    WHERE student_code IS NULL OR student_code = ''
    ORDER BY created_at
  LOOP
    -- Build prefix from name
    parts := regexp_split_to_array(trim(rec.full_name), '\s+');
    IF array_length(parts, 1) >= 2 THEN
      prefix := upper(left(parts[1], 1)) || lower(left(parts[array_length(parts,1)], 1));
    ELSE
      prefix := upper(left(parts[1], 1)) || lower(substring(parts[1], 2, 1));
    END IF;

    -- Get next sequence for this prefix
    SELECT COUNT(*) + 1 INTO seq
    FROM students
    WHERE student_code LIKE prefix || '-%';

    code := prefix || '-' || lpad(seq::text, 3, '0');

    -- Handle duplicates by incrementing
    WHILE EXISTS (SELECT 1 FROM students WHERE student_code = code) LOOP
      seq := seq + 1;
      code := prefix || '-' || lpad(seq::text, 3, '0');
    END LOOP;

    UPDATE students SET student_code = code WHERE id = rec.id;
  END LOOP;
END $$;

-- Step 4: Verify — check your students now have codes
SELECT student_code, full_name, age, gender, grade
FROM students
ORDER BY student_code
LIMIT 20;

-- ═══════════════════════════════════════════════════════════
--  Done! Refresh your SIMS page — IDs and stats will show.
-- ═══════════════════════════════════════════════════════════

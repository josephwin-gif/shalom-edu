-- ═══════════════════════════════════════════════════════════
--  SHALOM SIMS — Full Setup SQL (run in Supabase SQL Editor)
-- ═══════════════════════════════════════════════════════════

-- ── 1. Students table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id            uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  student_code  text        UNIQUE,   -- e.g. Jw-001
  full_name     text        NOT NULL,
  full_name_mm  text,
  age           integer,
  gender        text,
  grade         text,
  address       text,
  photo_url     text,
  notes         text,
  created_at    timestamptz DEFAULT now()
);

-- Add student_code column if upgrading from old table
ALTER TABLE students ADD COLUMN IF NOT EXISTS student_code text UNIQUE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS age          integer;
ALTER TABLE students ADD COLUMN IF NOT EXISTS address      text;

-- ── 2. Guardians ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS guardians (
  id           uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id   uuid        REFERENCES students(id) ON DELETE CASCADE,
  name         text        NOT NULL,
  relationship text,
  phone        text,
  address      text,
  is_emergency boolean     DEFAULT false,
  created_at   timestamptz DEFAULT now()
);

-- ── 3. Subjects ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subjects (
  id         uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  name       text        NOT NULL,
  grade      text,
  created_at timestamptz DEFAULT now()
);

-- ── 4. Academic Records ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS academic_records (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id  uuid        REFERENCES students(id) ON DELETE CASCADE,
  subject_id  uuid        REFERENCES subjects(id) ON DELETE SET NULL,
  term        text,
  year        text,
  score       numeric(5,2),
  grade_label text,
  remarks     text,
  created_at  timestamptz DEFAULT now()
);

-- ── Row Level Security ───────────────────────────────────────
ALTER TABLE students         ENABLE ROW LEVEL SECURITY;
ALTER TABLE guardians        ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects         ENABLE ROW LEVEL SECURITY;
ALTER TABLE academic_records ENABLE ROW LEVEL SECURITY;

-- Drop old policies safely
DROP POLICY IF EXISTS "Admin access students"         ON students;
DROP POLICY IF EXISTS "Admin access guardians"        ON guardians;
DROP POLICY IF EXISTS "Admin access subjects"         ON subjects;
DROP POLICY IF EXISTS "Admin access academic_records" ON academic_records;
DROP POLICY IF EXISTS "Student read own record"       ON students;
DROP POLICY IF EXISTS "Student read own guardians"    ON guardians;
DROP POLICY IF EXISTS "Student read own academics"    ON academic_records;
DROP POLICY IF EXISTS "Public read subjects"          ON subjects;

-- Admin (authenticated) — full access
CREATE POLICY "Admin access students"
  ON students FOR ALL
  TO authenticated
  USING (true) WITH CHECK (true);

CREATE POLICY "Admin access guardians"
  ON guardians FOR ALL
  TO authenticated
  USING (true) WITH CHECK (true);

CREATE POLICY "Admin access subjects"
  ON subjects FOR ALL
  TO authenticated
  USING (true) WITH CHECK (true);

CREATE POLICY "Admin access academic_records"
  ON academic_records FOR ALL
  TO authenticated
  USING (true) WITH CHECK (true);

-- Public (students) — read only via student_code lookup
CREATE POLICY "Student read own record"
  ON students FOR SELECT
  TO anon
  USING (true);   -- filtered in app by student_code

CREATE POLICY "Student read own guardians"
  ON guardians FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Student read own academics"
  ON academic_records FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Public read subjects"
  ON subjects FOR SELECT
  TO anon
  USING (true);

-- ── Sample subjects ──────────────────────────────────────────
INSERT INTO subjects (name) VALUES
  ('Mathematics'), ('English Language'), ('Myanmar Language'),
  ('Science'), ('Social Studies'), ('Christian Education'),
  ('Art'), ('Physical Education')
ON CONFLICT DO NOTHING;

-- ═══════════════════════════════════════════════════════════
--  IMPORTANT: Create admin account
--  Go to Supabase → Authentication → Users → Add User
--  Email: admin@shalom.edu  Password: (your choice)
--  This account is used for SIMS admin login.
-- ═══════════════════════════════════════════════════════════

-- ── Academic Records (updated for report card system) ────────
-- Add subject_name column for direct name storage (no FK needed)
ALTER TABLE academic_records ADD COLUMN IF NOT EXISTS subject_name text;

-- Update RLS for academic_records
DROP POLICY IF EXISTS "Allow all access to academic_records" ON academic_records;
DROP POLICY IF EXISTS "Admin access academic_records"        ON academic_records;
CREATE POLICY "Allow all academic_records"
  ON academic_records FOR ALL USING (true) WITH CHECK (true);

-- ═══════════════════════════════════════════════════════════
--  STORAGE POLICY FIX
--  Run this in: Supabase → SQL Editor → New Query → Run
--  Fixes: 400 errors when loading/uploading images
-- ═══════════════════════════════════════════════════════════

-- Drop old policies first to avoid duplicate errors
DROP POLICY IF EXISTS "Allow public uploads to gallery-photos"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads from gallery-photos"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public deletes from gallery-photos" ON storage.objects;
DROP POLICY IF EXISTS "Allow public uploads to general"          ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads from general"          ON storage.objects;
DROP POLICY IF EXISTS "Allow public uploads to article-images"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads from article-images"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public uploads to teacher-photos"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads from teacher-photos"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public uploads to student-photos"   ON storage.objects;
DROP POLICY IF EXISTS "Allow public reads from student-photos"   ON storage.objects;

-- ── gallery-photos ──────────────────────────────────────────
CREATE POLICY "Allow public uploads to gallery-photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'gallery-photos');

CREATE POLICY "Allow public reads from gallery-photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'gallery-photos');

CREATE POLICY "Allow public deletes from gallery-photos"
ON storage.objects FOR DELETE
USING (bucket_id = 'gallery-photos');

CREATE POLICY "Allow public updates to gallery-photos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'gallery-photos');

-- ── general (logo, hero) ────────────────────────────────────
CREATE POLICY "Allow public uploads to general"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'general');

CREATE POLICY "Allow public reads from general"
ON storage.objects FOR SELECT
USING (bucket_id = 'general');

CREATE POLICY "Allow public updates to general"
ON storage.objects FOR UPDATE
USING (bucket_id = 'general');

-- ── article-images ──────────────────────────────────────────
CREATE POLICY "Allow public uploads to article-images"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'article-images');

CREATE POLICY "Allow public reads from article-images"
ON storage.objects FOR SELECT
USING (bucket_id = 'article-images');

CREATE POLICY "Allow public updates to article-images"
ON storage.objects FOR UPDATE
USING (bucket_id = 'article-images');

-- ── teacher-photos ──────────────────────────────────────────
CREATE POLICY "Allow public uploads to teacher-photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'teacher-photos');

CREATE POLICY "Allow public reads from teacher-photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'teacher-photos');

CREATE POLICY "Allow public updates to teacher-photos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'teacher-photos');

-- ── student-photos ──────────────────────────────────────────
CREATE POLICY "Allow public uploads to student-photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'student-photos');

CREATE POLICY "Allow public reads from student-photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'student-photos');

CREATE POLICY "Allow public updates to student-photos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'student-photos');

-- ═══════════════════════════════════════════════════════════
--  Done! All storage buckets now allow public read/write.
-- ═══════════════════════════════════════════════════════════
